#include "Lab12Matam.h"
typedef struct  ListNode
{
	void* data;
	struct  ListNode* next;
} ListNode;

BOOL insertEntry(PNode* head, PNode* tail, void* data, compare_func func) {

	PNode temp, q;
	q = *head;

	temp = (PNode)malloc(sizeof(ListNode));
	if (temp == NULL)
		return FALSE; //in case that memo allocation failed.

	temp->data = data;
	temp->next = NULL;

	if (*head == NULL) { //empty list
		*head = temp;
		*tail = temp;
		return TRUE;
	}

	while (q != NULL) {
		if (func(q->data, temp->data)==TRUE) {
			printf("data is already exist");
			return FALSE;
		}
		q = q->next;
	}
	// if we got here we need to add the node.

	(*tail)->next = temp;
	*tail = temp;

	return TRUE;



}
	 
BOOL deleteNode(PNode* head, PNode* tail, void* todel, compare_func func1, free_func func2) {
	PNode temp, q;
	q = *head;

	//case for the first node in the list (delete from the head)
	
	if (func1(q->data, todel)) {
		temp = *head;
		*head = (*head)->next;
		func2(temp->data);
		free(temp);
		return TRUE;
	}

	//once we got here we know that the first NODE in the list is not the node that we want to delete.
	while (q->next != NULL) {		
		if (func1(q->next->data, todel)==TRUE) {
			temp = q->next; //the node that we want to delete. 
			q->next = q->next->next;
			func2(temp->data);
			free(temp);
			return TRUE;

		}
		q = q->next;
	}

	return FALSE; // we couldn't find the NODE that stores the "todel" provided data.
	
}

void printAll(PNode head, print_func func) {
	PNode q = head;

	while (q != NULL) {
		func(q->data);
		q = q->next;
	}
	
}

void freeAll(PNode* head, free_func func) {
	PNode temp;

	while (*head != NULL) {
		temp = *head;
		*head = (*head)->next;
		func(temp->data);
		free(temp);
	}

}