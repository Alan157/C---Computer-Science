#include "Lab12Matam.h"
//compare_func

void free_char(char *c) {
	free(c);
}

BOOL cmp_char(char* a, char* b) {
	
	if (*a == *b) 
		return TRUE;

	return FALSE;
}

void prnt_char(char *c) {
	printf("%c", *c);
}




int main()
{
	char ch, * temp;
	int n, i;
	BOOL res;
	PNode head = NULL, tail = NULL;

	printf("Enter number of characters ");
	scanf("%d", &n);
	printf("\nEnter %d characters,separated by enter", n);
	for (i = 0; i < n; i++)
	{
		temp = (char*)malloc(sizeof(char));
		if (NULL == temp)
		{
			printf("\nCan't allocate data memory");
			freeAll(&head, free_char);
			return 1;
		}
		scanf(" %c", temp);
		res = insertEntry(&head, &tail, temp, cmp_char);
		if (FALSE == res)  /* Can't allocate node memory or data is already exists*/
		{
			printf("\nCan't allocate node memory or data is already exists");
			freeAll(&head, free_char);
			return 1;
		}
	}
	printAll(head, prnt_char);

	printf("\nEnter an element for deleting");
	scanf(" %c", &ch);
	res = deleteNode(&head, &tail, &ch, cmp_char, free_char);
	if (FALSE == res)
		printf("%c don't exists in list\n", ch);

	printAll(head, prnt_char);

	freeAll(&head, free_char);
	printf("\nYour list was destroyed\n");

	return 0;
}

